"""
Simple Math Toolkit
A simple toolkit for basic mathematical operations
"""

from . import calculator

__version__ = "0.1.0"
__author__ = "KROKODILCHIK256" 